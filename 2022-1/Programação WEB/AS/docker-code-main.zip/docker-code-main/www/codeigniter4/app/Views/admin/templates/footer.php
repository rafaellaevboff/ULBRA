            </article>
        </div>
    </section>

    <footer class="barras text-black p-3 text-center">
        <h2>Rafaella E. Boff</h2>
        <a class="contatoRafa" target="_blank" style="text-decoration:none" href="https://www.linkedin.com/in/rafaellaevaldtboff/">Linkedin</a>
        <a class="contatoRafa" target="_blank" style="text-decoration:none" href="https://github.com/rafaellaevboff">GitHub</a> <br>
        <a class="mt-4" href="<?=base_url('/')?>">Área inicial</a>
    </footer>
</body>
</html>