            </article>
        </div>
    </section>

    <footer class="bg-dark text-light p-3 text-center">
        <h2>Rafaella E. Boff</h2>
        <a class="contatoRafa" target="_blank" style="text-decoration:none" href="https://www.linkedin.com/in/rafaellaevaldtboff/">Linkedin</a>
        <a class="contatoRafa" target="_blank" style="text-decoration:none" href="https://github.com/rafaellaevboff">GitHub</a>
        <a href=".../index.php">Área administrativa</a>
    </footer>
</body>
</html>