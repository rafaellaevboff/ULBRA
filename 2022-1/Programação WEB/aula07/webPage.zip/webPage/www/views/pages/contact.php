<h1>Contato</h1>
<form class="form" action="" method="get">
    <div class="mb-3 mt-3">
        <label class="form-label" for="">Nome</label>
        <input class="form-control" type="text">
    </div>
    <input class="btn btn-dark" type="button" value="Enviar">
</form>