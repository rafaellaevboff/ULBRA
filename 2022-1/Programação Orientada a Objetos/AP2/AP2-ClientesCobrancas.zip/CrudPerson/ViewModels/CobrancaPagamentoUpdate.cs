namespace CrudPerson.ViewModels
{
    public class CobrancaPagamentoUpdate
    {
        public DateTime DataPagamento { get; set; }
    }
}