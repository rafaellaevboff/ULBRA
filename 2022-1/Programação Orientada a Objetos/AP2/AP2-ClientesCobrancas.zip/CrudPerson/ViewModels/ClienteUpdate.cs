namespace CrudPerson.ViewModels
{
  public class ClienteUpdate
  {
    public string Nome { get; set; }
    public string Email { get; set; }
    public string Cpf { get; set; }
    public string Fone { get; set; }
    public string Endereco { get; set; }
  }
}