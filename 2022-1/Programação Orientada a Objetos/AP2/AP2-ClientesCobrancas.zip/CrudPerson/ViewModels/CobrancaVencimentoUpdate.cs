namespace CrudPerson.ViewModels
{
    public class CobrancaVencimentoUpdate
    {
        public DateTime DataVencimento { get; set; }
    }
}