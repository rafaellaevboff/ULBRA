using System.Collections.Generic;
using CrudPerson.Domains;

namespace CrudPerson.Models.Repositories
{
  public interface IClienteRepository : IBaseRepository<Cliente>
  {

  }
}